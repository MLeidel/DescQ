A Desktop Command & Query launcher


You've hopefully unzipped all the files
from the DESCQ.zip file into a folder somewhere
in your home directory.

The following is all required.
(you may have some or all of it already)

sudo apt-get install gcc
sudo apt-get install libgtk-3-dev
sudo apt-get install libgtk-3-0
sudo apt-get install libcurl4-openssl-dev
sudo apt-get install gedit


Once cURL is installed, you can download
the cURL library files from the official cURL
website if you wish to update them. They are
already included here in the "curl" directory.


Finally, run the command "sudo ldconfig" to update
the library cache and you should be able to
use the cURL library in your c programs.

run compile.sh to compile descq.c

run setupData.sh to copy the "data" files
to the live location at ~/.config/descq/data

If descq compiled with no errors you should be good
to go. You can place descq somewhere else in your
system path and it will find the "data" files.

For more info once descq is running enter: help (Enter)

To adjust the height and width use the "cap" command
to toggle the window caption bar on and off. 
Use "winset" to save the position.
Also you may have to edit the winmet.txt file 
to make finer adjustments.


 
